import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(public http:HttpClient) { }

  login(user)
  {
    return this.http.post("http://localhost:8001/userslogin",user);
  }

  insertUser(user)
  {
    return this.http.post("http://localhost:8001/users",user);
  }

  allDoctors()
  {
    return this.http.get("http://localhost:8001/doctors");
  }

  select()
  {
    return this.http.get("http://localhost:8001/");
  }

  selectbyNo(No)
  {
    return this.http.get("http://localhost:8001/" + No);
  }


  delete(No)
  {
    return this.http.delete("http://localhost:8001/" + No);
  }

  update(empobj)
  {
    return this.http.put("http://localhost:8001/" +empobj.No, empobj);
  }

  insert(empobj)
  {
    return this.http.post("http://localhost:8001/",empobj);
  }
}
