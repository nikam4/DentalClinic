import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit 
{
  doctors:any;
  dr1:any
  dr2:any
  dr3:any
  dr4:any
  key:number
  constructor(private service:DataService){  }

  ngOnInit() 
  {
    let observableResult=this.service.allDoctors();

    observableResult.subscribe((result)=>{
      console.log(result);
      console.log(result);
      this.doctors=result
      
      // this.doctors=result;
    });


  }

}
