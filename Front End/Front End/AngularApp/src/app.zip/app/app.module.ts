import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { AboutComponent } from './about/about.component';
import { EditComponent } from './edit/edit.component';
import { DeleteComponent } from './delete/delete.component';
import { RegisterComponent } from './register/register.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { RouterModule } from '@angular/router';
import {NgModel,NgForm,FormsModule} from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { AuthService } from './auth.service';
import { ProfileComponent } from './profile/profile.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { ReportsComponent } from './reports/reports.component';
import { AppointmentsComponent } from './appointments/appointments.component';
import { BookAppointmentComponent } from './book-appointment/book-appointment.component';
import { EditAppointmentComponent } from './edit-appointment/edit-appointment.component';
import { DoctorprofileComponent } from './doctorprofile/doctorprofile.component';
import { AdminComponent } from './admin/admin.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    EditComponent,
    DeleteComponent,
    RegisterComponent,
    NotfoundComponent,
    LoginComponent,
    ProfileComponent,
    ChangepasswordComponent,
    ReportsComponent,
    AppointmentsComponent,
    BookAppointmentComponent,
    EditAppointmentComponent,
    DoctorprofileComponent,
    AdminComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot([
      { path:"",component:LoginComponent },

      { path:"home",component:HomeComponent },
      { path:"about",component:AboutComponent },
      { path:"register",component:RegisterComponent},
      { path:"login",component:LoginComponent },
      { path:"profile",component:ProfileComponent, canActivate:[AuthService] },
      { path:"changepassword",component:ChangepasswordComponent, canActivate:[AuthService] },
      { path:"reports",component:ReportsComponent, canActivate:[AuthService] },
      { path:"appointments",component:AppointmentsComponent, canActivate:[AuthService] },
      { path:"newappointment",component:BookAppointmentComponent, canActivate:[AuthService] },
      { path:"editappointments",component:EditAppointmentComponent, canActivate:[AuthService] },
      { path:"drprofile",component:DoctorprofileComponent, canActivate:[AuthService] },
      { path:"admin",component:AdminComponent, canActivate:[AuthService] },


      { path:"edit/:No",component:EditComponent,canActivate:[AuthService]},
      { path:"delete/:No",component:DeleteComponent,canActivate:[AuthService] },
      
      { path:"**",component:NotfoundComponent },
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
