// import { Component, OnInit } from '@angular/core';
// import { AuthService } from '../auth.service';
// import { Router } from '@angular/router';

// @Component({
//   selector: 'app-login',
//   templateUrl: './login.component.html',
//   styleUrls: ['./login.component.css']
// })
// export class LoginComponent implements OnInit {

//   userdetails=
//   {
//     Email:"",
//     Password:""
//   };
//   constructor(private AuthService:AuthService,private router:Router) 
//   { 

//   }

//   ngOnInit()
//   {

//   }
//   message;
//   SignIn()
//   {
//     let isvalid=this.AuthService.checkUser(this.userdetails);
//     if(isvalid)
//     {
//       this.router.navigate(['home']);
//     }
//     else
//     {
//       this.message="Email or Password is wrong";
//     }
//   }
//   onSignup() {
//     this.router.navigate(['/register']);
//   }

// }



// import { Component, OnInit } from '@angular/core';
// import { Router } from '@angular/router';
// import { AuthService } from '../auth.service';

// import { toUnicode } from 'punycode';
// import { EmitterserviceService } from '../emitterservice.service';

// @Component({
//   selector: 'app-login',
//   templateUrl: './login.component.html',
//   styleUrls: ['./login.component.css']
// })
// export class LoginComponent implements OnInit {

//   userdetails={uname:"",password:""}
//   user={"role":""};

//   constructor(
//     private emtService:EmitterserviceService,
//     private router: Router,
//     private auth:AuthService ) { }


//   ngOnInit() {
//   }
//   message;

//   SignIn() {

//     if (this.userdetails.uname.length == 0) {
//       alert('Enter email');
//     } else if (this.userdetails.password.length ==0) {
//       alert('Enter password');
//     }
//     else {
//        this.user.role= this.auth.checkUser(this.userdetails)

//       if(this.user.role)
//           {
//             if(this.user.role=='ADMIN')
//             {
//                 sessionStorage['login_status'] = '1';
//                 localStorage.setItem('email',this.userdetails.uname);
//                 localStorage.setItem('flag','true');
//                 this.router.navigate(['/admin']);
//             }
//             else if(this.user.role=='DOCTOR')
//             {

//                 sessionStorage['login_status'] = '1';
//                 localStorage.setItem('email',this.userdetails.uname);
//                 localStorage.setItem('flag','true');
//                // this.emtService.navBarSwitch(true);
//                 this.router.navigate(['/drprofile']);
//             }
//             else if(this.user.role=='PATIENT')
//             {
//                 sessionStorage['login_status'] = '1';
//                 localStorage.setItem('email',this.userdetails.uname);
//                 localStorage.setItem('flag','true');
//                // this.emtService.navBarSwitch(true);
//                 this.router.navigate(['/home']);
//             }
//           }
//             else{
//               alert("invalid login");
//               this.router.navigate(['']);
//             }



//     }
//   }

//   onSignup() {
//     this.router.navigate(['/register']);
//   }
// }


import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  // Email:"";
  // Password:"";
  userdetail = { email: "", password: "" };
  user: any;

  constructor(private root: ActivatedRoute,
    private router: Router,
    private service: DataService,
    private auth: AuthService) { }

  ngOnInit() {

  }
  SignIn() {

    if (this.userdetail.email.length == 0) {
      alert('Enter email');
    } else if (this.userdetail.password.length == 0) {
      alert('Enter password');
    }
    else {

      let observableResult = this.service.login(this.userdetail);
      observableResult.subscribe((result) => {
        console.log(result);
        this.user = result;


        // this.user.role= this.auth.checkUser(this.userdetails)

        if (this.user.role) {
          if (this.user.role == 'ADMIN') {
            sessionStorage['login_status'] = '1';
            localStorage.setItem('email', this.userdetail.email);
            localStorage.setItem('uname', this.user.firstName);
            localStorage.setItem('flag', 'true');
            this.router.navigate(['/admin']);
          }
          else if (this.user.role == 'DOCTOR') {

            sessionStorage['login_status'] = '1';
            localStorage.setItem('email', this.userdetail.email);
            localStorage.setItem('uname', this.user.firstName);
            localStorage.setItem('flag', 'true');
            // this.emtService.navBarSwitch(true);
            this.router.navigate(['/drprofile']);
          }
          else if (this.user.role == 'PATIENT') {
            sessionStorage['login_status'] = '1';
            localStorage.setItem('email', this.userdetail.email);
            localStorage.setItem('uname', this.user.firstName);
            localStorage.setItem('flag', 'true');
            // this.emtService.navBarSwitch(true);
            this.router.navigate(['/home']);
          }
        }
        else {
          alert("invalid login");
          this.router.navigate(['']);
        }
      })
    }
  }
  onSignup() {
    this.router.navigate(['/register']);
  }
}