import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit 
{
  emp={"No":"","Name":"","Age":""};
  
  constructor(private root:ActivatedRoute,
              private router:Router,
              private service:DataService)
  { 

  }

  ngOnInit() 
  {
    this.root.paramMap.subscribe((result)=>{
      let No = result.get("No");

      let observableResult = this.service.selectbyNo(No);

      observableResult.subscribe((data)=>{
        console.log(data);

        this.emp=data[0];
      });

    });
  }
  update()
  {
    console.log(this.emp);
   let observableResult= this.service.update(this.emp);
   observableResult.subscribe((result)=>{
     console.log(result);

     this.router.navigate(['/home']);
   })
  }
}
